$(document).ready(function(){
    console.log("Loaded")
    $('.event-details div').hide();
    $('#event-date').show();
    $('#edate').click(function(){
        $('.event-details div').hide();
        $('#event-date').show();
    });
    $('#einfo').click(function(){
        $('.event-details div').hide();
        $('#event-descp').show();
    })
    $('#eusers').click(function(){
        $('.event-details div').hide();
        $('#event-users').show();
    })
    $('.emessages').click(function(){
        $('.event-details div').hide();
        $('#event-messages').show();
    });
});