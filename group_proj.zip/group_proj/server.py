from flask import Flask, render_template, redirect, request, session, flash
from mysqlconnection import connectToMySQL
from flask_bcrypt import Bcrypt   
from datetime import datetime
from pygeocoder import Geocoder
import re, datetime

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
app = Flask(__name__)
app.secret_key = "gandalf"
bcrypt = Bcrypt(app)
API_KEY = "AIzaSyBR1BxwvbBIclIGzaZdyDmfS-gtnmdXd0Q"

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register", methods=["POST"])
def register_user():
    is_valid = True
    
    if len(request.form['first_name']) < 2:
        is_valid = False
        flash("First name must be at least 2 characters long")
    if len(request.form['last_name']) < 2:
        is_valid = False
        flash("Last name must be at least 2 characters long")
    if len(request.form['password']) < 8:
        is_valid = False
        flash("Password must be at least 8 characters long")
    if request.form['c_password'] != request.form['password']:
        is_valid = False
        flash("Passwords must match")
    if not EMAIL_REGEX.match(request.form['email']):
        is_valid = False
        flash("Please use a valid email address")
    else:
        mysql = connectToMySQL('mydb')
        query = "SELECT * FROM user WHERE user.email = %(email)s"
        data = {
            'email': request.form['email']
        }
        user = mysql.query_db(query, data)
        if user:
            is_valid = False
            flash("Please email address already in use")
    
    if is_valid:
        mysql = connectToMySQL('mydb')
        query = "INSERT into user (first_name, last_name, email, password, birthday_date, created_at, updated_at) VALUES (%(fn)s, %(ln)s, %(email)s, %(pass)s, NOW(), NOW(), NOW())"
        data = {
            'fn': request.form['first_name'],
            'ln': request.form['last_name'],
            'email': request.form['email'],
            'pass': bcrypt.generate_password_hash(request.form['password'])
        }
        user_id = mysql.query_db(query, data)
        session['user_id'] = user_id

        return redirect("/dashboard")
    else:
        return redirect("/")

@app.route("/login", methods=["POST"])
def login_user():
    is_valid = True

    if len(request.form['email']) < 1:
        is_valid = False
        flash("Please enter your email")
    if len(request.form['password']) < 1:
        is_valid = False
        flash("Please enter your password")
    
    if not is_valid:
        return redirect("/")
    else:
        mysql = connectToMySQL('mydb')
        query = "SELECT * FROM user WHERE user.email = %(email)s"
        data = {
            'email': request.form['email']
        }
        user = mysql.query_db(query, data)
        if user:
            hashed_password = user[0]['password']
            if bcrypt.check_password_hash(hashed_password, request.form['password']):
                session['user_id'] = user[0]['id']
                return redirect("/dashboard")
            else:
                flash("Password is invalid")
                return redirect("/")
        else:
            flash("Please use a valid email address")
            return redirect("/")

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

@app.route("/dashboard")
def dashboard():
    if 'user_id' not in session:
        return redirect('/')

    mysql = connectToMySQL('mydb')
    query = "SELECT * FROM user WHERE user.id = %(id)s"
    data = {
        'id': session['user_id']
    }
    user = mysql.query_db(query, data)

    mysql = connectToMySQL('mydb')
    query = "SELECT * FROM event WHERE user_id = %(user)s;"
    data = {
        'user':session['user_id']
    }
    user_event = mysql.query_db(query,data)
    today = datetime.datetime.now()
    return render_template("dashboard.html", user=user[0], event=user_event, today=today)

@app.route('/event/new')
def new():
    if 'user_id' not in session:
        return redirect('/')
    
    mysql = connectToMySQL('mydb')
    query = "SELECT * FROM user WHERE user.id = %(id)s"
    data = {
        'id': session['user_id']
    }
    user = mysql.query_db(query, data)

    return render_template('new.html', user=user[0])

@app.route('/event/create', methods=["POST"])
def add_event():
    if 'user_id' not in session:
        return redirect('/')

    if len(request.form['event_name']) <3:
        flash("Event must be at least three characters")
    if len(request.form['event_location']) <3:
        flash("Location must be at least three chracters")

    if '_flashes' not in session:
        mysql = connectToMySQL('mydb')
        query = "INSERT INTO event (event_name, event_location, attendee_number, event_date, user_id, created_at, updated_at) VALUES (%(event)s, %(location)s, %(attendees)s, %(event_date)s, %(user)s, NOW(), NOW())" 
        data ={
            'event' :request.form['event_name'],
            'location' :request.form['event_location'],
            'attendees' :request.form['attendee_number'],
            'event_date':request.form['event_date'],
            'user' :session['user_id']
        }
        mysql.query_db(query,data)
        return redirect('/dashboard')
    return redirect('/event/new')

@app.route("/search")
def search():

    mysql = connectToMySQL('mydb')
    query = "SELECT * FROM user WHERE user.id = %(id)s"
    data = {
        'id': session['user_id']
    }
    user = mysql.query_db(query, data)

    mysql = connectToMySQL('mydb')
    query = "SELECT * FROM event JOIN user ON user.id = event.user_id ORDER BY event.event_date DESC;"
    data = {
        'id': session['user_id'],
    }
    events = mysql.query_db(query, data)

    return render_template("search.html", user=user[0], events=events)

@app.route("/users/<user_id>")
def account(user_id):
    if 'user_id' not in session:
        return redirect('/')

    mysql = connectToMySQL('mydb')
    query = "SELECT * FROM user WHERE user.id = %(id)s"
    data = {
        'id': session['user_id']
    }
    user = mysql.query_db(query, data)

    mysql = connectToMySQL('mydb')
    query = "SELECT * FROM event WHERE user_id = %(user)s;"
    data = {
        'user':session['user_id']
    }
    user_event = mysql.query_db(query,data)
    today = datetime.datetime.now()

    return render_template("users.html", user=user[0], event=user_event, today=today)

@app.route('/event/<event_id>')
def event_details(event_id):
    mysql = connectToMySQL("mydb")
    query = "SELECT * FROM event JOIN user ON user.id = event.user_id WHERE event.idevent = %(evnt)s;"
    data = {
        'evnt' : event_id
    }
    event_info = mysql.query_db(query, data)
    results = Geocoder(api_key = API_KEY).geocode(event_info[0]['event_location'])
    print(results.coordinates)
    return render_template('events.html', info = event_info, API_KEY = API_KEY, lat_lng = results[0].coordinates)

if __name__ == "__main__":
    app.run(debug=True)